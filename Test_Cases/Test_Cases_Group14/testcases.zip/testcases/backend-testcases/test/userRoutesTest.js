const request = require("supertest");
const express = require("express");
const userRoutes = require("./userRoutes");
const User = require("../models/User");

jest.mock("../models/User");

const app = express();
app.use(express.json());
app.use("/", userRoutes);

describe("User Routes", () => {
  afterEach(() => {
    jest.clearAllMocks();
  });

  describe("GET /", () => {
    test("should fetch all users", async () => {
      User.find.mockResolvedValueOnce([
        { name: "Alice", email: "alice@example.com" },
        { name: "Bob", email: "bob@example.com" },
      ]);
      const response = await request(app).get("/");
      expect(response.status).toBe(200);
      expect(response.body).toHaveLength(2);
    });

    test("should return 500 on database error", async () => {
      User.find.mockRejectedValueOnce(new Error("Database Error"));
      const response = await request(app).get("/");
      expect(response.status).toBe(500);
      expect(response.body.message).toBe("Database Error");
    });
  });

  describe("GET /:id", () => {
    test("should fetch a specific user", async () => {
      User.findById.mockResolvedValueOnce({
        _id: "123",
        name: "Alice",
        email: "alice@example.com",
      });
      const response = await request(app).get("/123");
      expect(response.status).toBe(200);
      expect(response.body.name).toBe("Alice");
    });

    test("should return 404 if user not found", async () => {
      User.findById.mockResolvedValueOnce(null);
      const response = await request(app).get("/123");
      expect(response.status).toBe(404);
      expect(response.body.message).toBe("Cannot find user");
    });

    test("should return 500 on database error", async () => {
      User.findById.mockRejectedValueOnce(new Error("Database Error"));
      const response = await request(app).get("/123");
      expect(response.status).toBe(500);
      expect(response.body.message).toBe("Database Error");
    });
  });

  describe("PATCH /:id", () => {
    test("should update user details", async () => {
      User.findById.mockResolvedValueOnce({
        _id: "123",
        name: "Alice",
        email: "alice@example.com",
        save: jest.fn().mockResolvedValueOnce({ name: "Updated Alice" }),
      });

      const response = await request(app)
        .patch("/123")
        .send({ name: "Updated Alice" });
      expect(response.status).toBe(200);
      expect(response.body.name).toBe("Updated Alice");
    });

    test("should return 400 if update fails", async () => {
      User.findById.mockResolvedValueOnce({
        _id: "123",
        name: "Alice",
        email: "alice@example.com",
        save: jest.fn().mockRejectedValueOnce(new Error("Update Error")),
      });

      const response = await request(app)
        .patch("/123")
        .send({ name: "Updated Alice" });
      expect(response.status).toBe(400);
      expect(response.body.message).toBe("Update Error");
    });
  });

  describe("DELETE /:id", () => {
    test("should delete a user", async () => {
      User.findById.mockResolvedValueOnce({ _id: "123" });
      User.findByIdAndDelete.mockResolvedValueOnce();
      const response = await request(app).delete("/123");
      expect(response.status).toBe(200);
      expect(response.body.message).toBe("Deleted user");
    });

    test("should return 500 on delete error", async () => {
      User.findById.mockResolvedValueOnce({ _id: "123" });
      User.findByIdAndDelete.mockRejectedValueOnce(new Error("Delete Error"));
      const response = await request(app).delete("/123");
      expect(response.status).toBe(500);
      expect(response.body.message).toBe("Delete Error");
    });
  });

  describe("PATCH /:id/follow", () => {
    test("should follow a user successfully", async () => {
      User.findById.mockResolvedValueOnce({
        _id: "123",
        followers: [],
        save: jest.fn().mockResolvedValueOnce(),
      }).mockResolvedValueOnce({
        _id: "456",
        following: [],
        save: jest.fn().mockResolvedValueOnce(),
      });

      const response = await request(app)
        .patch("/123/follow")
        .send({ id: "456" });
      expect(response.status).toBe(200);
      expect(response.body.message).toBe("Successfully followed the user");
    });

    test("should return 404 if either user is not found", async () => {
      User.findById.mockResolvedValueOnce(null);
      const response = await request(app).patch("/123/follow").send({ id: "456" });
      expect(response.status).toBe(404);
      expect(response.body.message).toBe("User not found");
    });

    test("should return 400 if user tries to follow themselves", async () => {
      const response = await request(app).patch("/123/follow").send({ id: "123" });
      expect(response.status).toBe(400);
      expect(response.body.message).toBe("You cannot follow yourself");
    });

    test("should return 400 if user is already following the target user", async () => {
      User.findById.mockResolvedValueOnce({
        _id: "123",
        followers: ["456"],
        save: jest.fn(),
      }).mockResolvedValueOnce({
        _id: "456",
        following: ["123"],
        save: jest.fn(),
      });

      const response = await request(app)
        .patch("/123/follow")
        .send({ id: "456" });
      expect(response.status).toBe(400);
      expect(response.body.message).toBe("You are already following this user");
    });
  });
});
