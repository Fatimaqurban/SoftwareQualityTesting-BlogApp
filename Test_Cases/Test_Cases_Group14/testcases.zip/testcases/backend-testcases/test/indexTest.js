const request = require("supertest");
const express = require("express");
const jwt = require("jsonwebtoken");
const mongoose = require("mongoose");
const cookieParser = require("cookie-parser");
const authMiddleware = require("./middleware/authmiddleware");
const User = require("./models/User");
const app = express();
const dotenv = require("dotenv");

dotenv.config();

// Set up test environment
mongoose.connect(process.env.MONGO_TEST, { useNewUrlParser: true, useUnifiedTopology: true });

app.use(cookieParser());
app.use(express.json());

// Test routes
app.use("/user", authMiddleware, require("./routes/userRoutes"));
app.use("/blog", require("./routes/blogRoutes"));
app.use("/search", require("./routes/searchRoutes"));
app.use("/admin", authMiddleware, require("./routes/adminRoutes"));

describe("User Authentication and Route Access", () => {
  let testUser;
  let accessToken;

  beforeAll(async () => {
    // Create test user in the database
    testUser = new User({
      username: "testUser",
      email: "test@example.com",
      password: "password123",
      role: "user",
    });
    await testUser.save();

    // Generate JWT token for the test user
    accessToken = jwt.sign(
      { user_id: testUser._id, role: testUser.role },
      process.env.JWT_SECRET
    );
  });

  afterAll(async () => {
    // Clean up the test database after tests are done
    await User.deleteMany({});
    await mongoose.connection.close();
  });

  describe("POST /register", () => {
    test("should create a new user", async () => {
      const response = await request(app)
        .post("/register")
        .send({ username: "newUser", email: "newuser@example.com", password: "password123", role: "user" });
      expect(response.status).toBe(201);
      expect(response.text).toBe("User created successfully");
    });

    test("should return 400 if required fields are missing", async () => {
      const response = await request(app)
        .post("/register")
        .send({ username: "newUser", email: "newuser@example.com" });
      expect(response.status).toBe(400);
      expect(response.text).toBe("Bad request");
    });
  });

  describe("POST /login", () => {
    test("should log in user with correct credentials", async () => {
      const response = await request(app)
        .post("/login")
        .send({ email: testUser.email, password: "password123" });
      expect(response.status).toBe(200);
      expect(response.body.message).toBe("Logged in successfully");
      expect(response.body.accessToken).toBeDefined();
    });

    test("should return 400 if incorrect email is provided", async () => {
      const response = await request(app)
        .post("/login")
        .send({ email: "wrong@example.com", password: "password123" });
      expect(response.status).toBe(400);
      expect(response.text).toBe("Cannot find user");
    });

    test("should return 400 if incorrect password is provided", async () => {
      const response = await request(app)
        .post("/login")
        .send({ email: testUser.email, password: "wrongPassword" });
      expect(response.status).toBe(400);
      expect(response.text).toBe("Incorrect password");
    });

    test("should return 400 if the user is blocked", async () => {
      testUser.blocked = true;
      await testUser.save();

      const response = await request(app)
        .post("/login")
        .send({ email: testUser.email, password: "password123" });
      expect(response.status).toBe(400);
      expect(response.text).toBe("User is blocked");
    });
  });

  describe("Protected Routes", () => {
    test("should allow access to protected route with valid token", async () => {
      const response = await request(app)
        .get("/user")
        .set("Cookie", `jwt=${accessToken}`);
      expect(response.status).toBe(200);
    });

    test("should deny access to protected route without token", async () => {
      const response = await request(app).get("/user");
      expect(response.status).toBe(401);
      expect(response.body.message).toBe("Unauthorized");
    });

    test("should deny access to protected route with invalid token", async () => {
      const invalidToken = "invalidtoken";
      const response = await request(app)
        .get("/user")
        .set("Cookie", `jwt=${invalidToken}`);
      expect(response.status).toBe(401);
      expect(response.body.message).toBe("Unauthorized");
    });
  });
});
