const request = require("supertest");
const express = require("express");
const mongoose = require("mongoose");
const blogRoutes = require("./blogRoutes"); // Path to blogRoutes.js
const Blog = require("../models/Blog").Blog;
const User = require("../models/User");
const Comment = require("../models/Blog").Comment;

// Mock Database Connection
beforeAll(async () => {
  await mongoose.connect("mongodb://127.0.0.1:27017/testdb", {
    useNewUrlParser: true,
    useUnifiedTopology: true,
  });
});

afterAll(async () => {
  await mongoose.connection.dropDatabase();
  await mongoose.connection.close();
});

const app = express();
app.use(express.json());
app.use("/blogs", blogRoutes);

describe("Blog Routes Test Suite", () => {
  let blogId, userId, commentId;

  beforeAll(async () => {
    // Create a mock user
    const user = new User({ name: "Test User", following: [] });
    const savedUser = await user.save();
    userId = savedUser._id;

    // Create a mock blog
    const blog = new Blog({
      title: "Test Blog",
      content: "This is a test blog post.",
      author: userId,
      disabled: false,
    });
    const savedBlog = await blog.save();
    blogId = savedBlog._id;

    // Create a mock comment
    const comment = new Comment({
      text: "This is a test comment.",
      author: userId,
    });
    const savedComment = await comment.save();
    commentId = savedComment._id;

    await Blog.findByIdAndUpdate(blogId, { $push: { comments: savedComment } });
  });

  afterAll(async () => {
    await User.deleteMany();
    await Blog.deleteMany();
    await Comment.deleteMany();
  });

  test("Create a new blog post (True branch)", async () => {
    const response = await request(app).post("/blogs").send({
      title: "New Blog Post",
      content: "Content of the new blog post.",
      author: userId,
    });
    expect(response.status).toBe(200);
    expect(response.body).toHaveProperty("title", "New Blog Post");
  });

  test("GET all blogs excluding disabled blogs (True branch)", async () => {
    const response = await request(app).get("/blogs");
    expect(response.status).toBe(200);
    expect(response.body.length).toBeGreaterThan(0);
  });

  test("GET all blogs including disabled blogs", async () => {
    const response = await request(app).get("/blogs/all");
    expect(response.status).toBe(200);
    expect(response.body.length).toBeGreaterThan(0);
  });

  test("GET blogs of a specific author with pagination and sorting", async () => {
    const response = await request(app)
      .get(`/blogs/author/${userId}?page=1&limit=1&sortBy=title&sortOrder=asc`);
    expect(response.status).toBe(200);
    expect(response.body.results.length).toBeGreaterThan(0);
  });

  test("PATCH blog post with invalid author (False branch)", async () => {
    const response = await request(app)
      .patch(`/blogs/${blogId}`)
      .send({ author: mongoose.Types.ObjectId() });
    expect(response.status).toBe(200);
    expect(response.text).toBe("You are not authorized to update this blog post");
  });

  test("DELETE a blog post with invalid author (False branch)", async () => {
    const response = await request(app)
      .delete(`/blogs/${blogId}`)
      .send({ author: mongoose.Types.ObjectId() });
    expect(response.status).toBe(200);
    expect(response.text).toBe("You are not authorized to delete this blog post");
  });

  test("GET a specific blog post (True branch)", async () => {
    const response = await request(app).get(`/blogs/${blogId}`);
    expect(response.status).toBe(200);
    expect(response.body).toHaveProperty("title", "Test Blog");
  });

  test("Rate a blog post (Invalid rating)", async () => {
    const response = await request(app).patch(`/blogs/${blogId}/rate?rate=6`);
    expect(response.status).toBe(200);
    expect(response.text).toBe("Rate should be between 1 and 5");
  });

  test("POST comment on a blog", async () => {
    const response = await request(app)
      .post(`/blogs/${blogId}/comment`)
      .send({ text: "Another comment", author: userId });
    expect(response.status).toBe(200);
    expect(response.body.comments.length).toBeGreaterThan(1);
  });

  test("DELETE a comment from a blog", async () => {
    const response = await request(app).delete(`/blogs/${blogId}/comment/${commentId}`);
    expect(response.status).toBe(200);
    expect(response.body.comments.length).toBe(0);
  });
});
