const authMiddleware = require("./authmiddleware");
const jwt = require("jsonwebtoken");

// Mock dependencies and setup test utilities
jest.mock("jsonwebtoken");

describe("authMiddleware", () => {
  let req, res, next;

  beforeEach(() => {
    req = { cookies: {} };
    res = {
      status: jest.fn(() => res),
      json: jest.fn(),
    };
    next = jest.fn();
  });

  test("should return 401 if no token is provided", () => {
    authMiddleware(req, res, next);
    expect(res.status).toHaveBeenCalledWith(401);
    expect(res.json).toHaveBeenCalledWith({ msg: "No token, authorization denied" });
    expect(next).not.toHaveBeenCalled();
  });

  test("should call next if token is valid", () => {
    const mockToken = "validToken";
    const mockDecoded = { user: { id: "123" } };
    req.cookies.jwt = mockToken;

    jwt.verify.mockImplementation(() => mockDecoded);

    authMiddleware(req, res, next);
    expect(jwt.verify).toHaveBeenCalledWith(mockToken, process.env.JWT_SECRET);
    expect(req.user).toEqual(mockDecoded.user);
    expect(next).toHaveBeenCalled();
  });

  test("should return 401 if token is invalid", () => {
    const mockToken = "invalidToken";
    req.cookies.jwt = mockToken;

    jwt.verify.mockImplementation(() => {
      throw new Error("Invalid token");
    });

    authMiddleware(req, res, next);
    expect(jwt.verify).toHaveBeenCalledWith(mockToken, process.env.JWT_SECRET);
    expect(res.status).toHaveBeenCalledWith(401);
    expect(res.json).toHaveBeenCalledWith({ msg: "Token is not valid" });
    expect(next).not.toHaveBeenCalled();
  });
});
