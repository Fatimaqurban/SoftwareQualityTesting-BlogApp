const request = require("supertest");
const express = require("express");
const mongoose = require("mongoose");
const adminRoutes = require("./adminRoutes");
const User = require("../models/User");
const Blog = require("../models/Blog").Blog;

jest.mock("../models/User");
jest.mock("../models/Blog");

const app = express();
app.use(express.json());
app.use("/admin", adminRoutes);

describe("Admin Routes", () => {
  describe("GET /admin/users", () => {
    it("should fetch all users", async () => {
      const mockUsers = [{ id: "1", name: "John Doe" }];
      User.find.mockResolvedValue(mockUsers);

      const res = await request(app).get("/admin/users");
      expect(res.status).toBe(200);
      expect(res.body).toEqual(mockUsers);
    });

    it("should handle errors when fetching users", async () => {
      User.find.mockRejectedValue(new Error("Database error"));

      const res = await request(app).get("/admin/users");
      expect(res.status).toBe(500);
      expect(res.body).toHaveProperty("message", "Database error");
    });
  });

  describe("PATCH /admin/users/:id/disable", () => {
    it("should block/unblock a user", async () => {
      const mockUser = { id: "1", blocked: false, save: jest.fn() };
      User.findById.mockResolvedValue(mockUser);

      const res = await request(app)
        .patch("/admin/users/1/disable")
        .send({ blocked: true });

      expect(mockUser.blocked).toBe(true);
      expect(mockUser.save).toHaveBeenCalled();
      expect(res.status).toBe(200);
      expect(res.body.message).toBe("User unblocked successfully");
    });

    it("should not allow blocking oneself", async () => {
      const res = await request(app)
        .patch("/admin/users/1/disable")
        .send({ id: "1", blocked: true });

      expect(res.status).toBe(200);
      expect(res.body.message).toBe("Cannot block yourself");
    });

    it("should handle invalid block requests", async () => {
      const res = await request(app).patch("/admin/users/1/disable").send({});
      expect(res.status).toBe(400);
      expect(res.text).toBe("Bad request");
    });

    it("should handle errors during user blocking", async () => {
      User.findById.mockRejectedValue(new Error("Database error"));

      const res = await request(app)
        .patch("/admin/users/1/disable")
        .send({ blocked: true });

      expect(res.status).toBe(500);
      expect(res.body).toHaveProperty("message", "Database error");
    });
  });

  describe("GET /admin/blogs", () => {
    it("should fetch all blogs", async () => {
      const mockBlogs = [{ id: "1", title: "Test Blog" }];
      Blog.find.mockResolvedValue(mockBlogs);

      const res = await request(app).get("/admin/blogs");
      expect(res.status).toBe(200);
      expect(res.body).toEqual(mockBlogs);
    });

    it("should handle errors when fetching blogs", async () => {
      Blog.find.mockRejectedValue(new Error("Database error"));

      const res = await request(app).get("/admin/blogs");
      expect(res.status).toBe(500);
      expect(res.body).toHaveProperty("message", "Database error");
    });
  });

  describe("PATCH /admin/blogs/:id/disable", () => {
    it("should disable a blog post", async () => {
      const mockBlog = { id: "1", disabled: false, save: jest.fn() };
      Blog.findById.mockResolvedValue(mockBlog);

      const res = await request(app)
        .patch("/admin/blogs/1/disable")
        .send({ block: true });

      expect(mockBlog.disabled).toBe(true);
      expect(mockBlog.save).toHaveBeenCalled();
      expect(res.status).toBe(200);
      expect(res.body.message).toBe("Blog post disabled successfully");
    });

    it("should handle already disabled blogs", async () => {
      const mockBlog = { id: "1", disabled: true, save: jest.fn() };
      Blog.findById.mockResolvedValue(mockBlog);

      const res = await request(app)
        .patch("/admin/blogs/1/disable")
        .send({ block: true });

      expect(res.status).toBe(200);
      expect(res.text).toBe("Blog post is already disabled");
    });

    it("should handle invalid disable requests", async () => {
      const res = await request(app).patch("/admin/blogs/1/disable").send({});
      expect(res.status).toBe(400);
      expect(res.text).toBe("Bad request");
    });

    it("should handle errors during blog disabling", async () => {
      Blog.findById.mockRejectedValue(new Error("Database error"));

      const res = await request(app)
        .patch("/admin/blogs/1/disable")
        .send({ block: true });

      expect(res.status).toBe(500);
      expect(res.body).toHaveProperty("message", "Database error");
    });
  });
});
