const request = require("supertest");
const express = require("express");
const searchRoutes = require("./searchRoutes");
const Blog = require("../models/Blog").Blog;

jest.mock("../models/Blog");

const app = express();
app.use("/", searchRoutes);

describe("GET /search", () => {
  afterEach(() => {
    jest.clearAllMocks();
  });

  test("should return an empty result when text query is missing", async () => {
    const response = await request(app).get("/");
    expect(response.status).toBe(200);
    expect(response.body).toEqual({ results: [] });
  });

  test("should return paginated results with default sort and order", async () => {
    Blog.find.mockResolvedValueOnce([
      { title: "Title 1", content: "Content 1", disabled: false },
      { title: "Title 2", content: "Content 2", disabled: false },
    ]);
    Blog.countDocuments.mockResolvedValueOnce(10);

    const response = await request(app).get("/?text=test&page=1&limit=2");
    expect(response.status).toBe(200);
    expect(response.body.results).toHaveLength(2);
  });

  test("should return results with specified sort order and field", async () => {
    Blog.find.mockResolvedValueOnce([
      { title: "A Title", content: "Content A", disabled: false },
      { title: "B Title", content: "Content B", disabled: false },
    ]);
    const response = await request(app).get(
      "/?text=test&sortBy=content&sortOrder=desc"
    );
    expect(response.status).toBe(200);
    expect(response.body.results[0].content).toBe("Content B");
  });

  test("should handle invalid sortBy or sortOrder gracefully", async () => {
    Blog.find.mockResolvedValueOnce([
      { title: "Default Title", content: "Default Content", disabled: false },
    ]);
    const response = await request(app).get(
      "/?text=test&sortBy=invalid&sortOrder=invalid"
    );
    expect(response.status).toBe(200);
    expect(response.body.results[0].title).toBe("Default Title");
  });

  test("should handle server errors gracefully", async () => {
    Blog.find.mockRejectedValueOnce(new Error("Database Error"));
    const response = await request(app).get("/?text=test");
    expect(response.status).toBe(500);
    expect(response.body.message).toBe("Database Error");
  });

  test("should handle pagination (next page availability)", async () => {
    Blog.find
      .mockResolvedValueOnce([
        { title: "Title 1", content: "Content 1", disabled: false },
      ])
      .mockResolvedValueOnce([{ title: "Title 2", content: "Content 2" }]);
    Blog.countDocuments.mockResolvedValueOnce(5);

    const response = await request(app).get("/?text=test&page=1&limit=1");
    expect(response.body.next.page).toBe(2);
  });

  test("should handle no results found scenario", async () => {
    Blog.find.mockResolvedValueOnce([]);
    const response = await request(app).get("/?text=nonexistent");
    expect(response.status).toBe(200);
    expect(response.body.results).toHaveLength(0);
  });
});
