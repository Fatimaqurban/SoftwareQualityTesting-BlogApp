import { render, screen, fireEvent, waitFor } from '@testing-library/react';
import { BrowserRouter as Router } from 'react-router-dom';
import Admin from './Admin';
import axios from 'axios';
import Cookies from 'js-cookie';
import { toast } from 'react-toastify';

// Mock dependencies
jest.mock('axios');
jest.mock('js-cookie', () => ({
  get: jest.fn(),
}));
jest.mock('react-toastify', () => ({
  toast: {
    success: jest.fn(),
  },
}));

describe('Admin Component', () => {
  beforeEach(() => {
    Cookies.get.mockClear();
    axios.get.mockClear();
    toast.success.mockClear();
  });

  test('redirects to login if no token is provided', async () => {
    Cookies.get.mockReturnValue(null);

    const { container } = render(
      <Router>
        <Admin />
      </Router>
    );

    expect(container.textContent).not.toContain('Blog List');
  });

  test('fetches and displays blogs', async () => {
    Cookies.get.mockReturnValue('fakeToken');
    axios.get.mockResolvedValue({
      data: [
        { _id: '1', title: 'Blog 1', date: '2024-12-11', rate: { totalRating: 5, numberOfRatings: 10 }, author: 'Admin', comments: [] },
        { _id: '2', title: 'Blog 2', date: '2024-12-10', rate: { totalRating: 4, numberOfRatings: 5 }, author: 'Editor', comments: [] },
      ],
    });

    render(
      <Router>
        <Admin />
      </Router>
    );

    await waitFor(() => {
      expect(screen.getByText('Blog 1')).toBeInTheDocument();
      expect(screen.getByText('Blog 2')).toBeInTheDocument();
    });
  });

  test('handles new blog submission', async () => {
    Cookies.get.mockReturnValue('fakeToken');
    axios.get.mockResolvedValueOnce({ data: [] }); // For initial blogs
    axios.post.mockResolvedValueOnce({
      data: { _id: '3', title: 'New Blog', content: 'Content here', author: 'Admin' },
    });

    render(
      <Router>
        <Admin />
      </Router>
    );

    const addButton = screen.getByText('+');
    fireEvent.click(addButton);

    const titleInput = screen.getByPlaceholderText('Enter Title');
    const contentInput = screen.getByPlaceholderText('Enter Content');
    const submitButton = screen.getByText('Submit');

    fireEvent.change(titleInput, { target: { value: 'New Blog' } });
    fireEvent.change(contentInput, { target: { value: 'Content here' } });
    fireEvent.click(submitButton);

    await waitFor(() => {
      expect(toast.success).toHaveBeenCalledWith('Blog added successfully!');
    });
  });
});
