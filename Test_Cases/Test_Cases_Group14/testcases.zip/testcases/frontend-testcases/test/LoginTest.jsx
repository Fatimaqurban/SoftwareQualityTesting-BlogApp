import { render, screen, fireEvent, waitFor } from '@testing-library/react';
import Login from './Login';
import axios from 'axios';
import { BrowserRouter as Router } from 'react-router-dom';

// Mock the toast notifications
jest.mock('react-toastify', () => ({
  ToastContainer: () => <div />,
  toast: {
    error: jest.fn(),
    success: jest.fn(),
  },
}));

jest.mock('axios');

describe('Login Component', () => {
  test('renders Login and SignUp forms correctly', () => {
    render(
      <Router>
        <Login tokenEmptyy={false} />
      </Router>
    );

    // Login form
    expect(screen.getByPlaceholderText('Email')).toBeInTheDocument();
    expect(screen.getByPlaceholderText('Password')).toBeInTheDocument();
    expect(screen.getByText('Log in')).toBeInTheDocument();

    // SignUp form
    fireEvent.click(screen.getByRole('checkbox'));
    expect(screen.getByPlaceholderText('Username')).toBeInTheDocument();
    expect(screen.getByText('Sign up')).toBeInTheDocument();
  });

  test('shows error when email and password are empty during login', async () => {
    render(
      <Router>
        <Login tokenEmptyy={false} />
      </Router>
    );

    fireEvent.click(screen.getByText('Confirm!'));

    await waitFor(() => expect(axios.post).not.toHaveBeenCalled());
    expect(toast.error).toHaveBeenCalledWith('Please fill all the fields');
  });

  test('shows error when email and password are empty during signup', async () => {
    render(
      <Router>
        <Login tokenEmptyy={false} />
      </Router>
    );

    fireEvent.click(screen.getByRole('checkbox'));
    fireEvent.click(screen.getByText('Confirm!'));

    await waitFor(() => expect(axios.post).not.toHaveBeenCalled());
    expect(toast.error).toHaveBeenCalledWith('Please fill all the fields');
  });

  test('submits login successfully', async () => {
    axios.post.mockResolvedValueOnce({ data: { accessToken: 'mock-token' } });

    render(
      <Router>
        <Login tokenEmptyy={false} />
      </Router>
    );

    fireEvent.change(screen.getByPlaceholderText('Email'), {
      target: { value: 'test@test.com' },
    });
    fireEvent.change(screen.getByPlaceholderText('Password'), {
      target: { value: 'password' },
    });

    fireEvent.click(screen.getByText('Confirm!'));

    await waitFor(() => expect(axios.post).toHaveBeenCalled());
    expect(toast.success).toHaveBeenCalledWith('Logged in successfully');
  });

  test('submits signup successfully', async () => {
    axios.post.mockResolvedValueOnce({ data: { success: true } });

    render(
      <Router>
        <Login tokenEmptyy={false} />
      </Router>
    );

    fireEvent.click(screen.getByRole('checkbox'));

    fireEvent.change(screen.getByPlaceholderText('Username'), {
      target: { value: 'testuser' },
    });
    fireEvent.change(screen.getByPlaceholderText('Email'), {
      target: { value: 'test@test.com' },
    });
    fireEvent.change(screen.getByPlaceholderText('Password'), {
      target: { value: 'password' },
    });

    fireEvent.click(screen.getByText('Confirm!'));

    await waitFor(() => expect(axios.post).toHaveBeenCalled());
    expect(toast.success).toHaveBeenCalledWith('Signed up successfully');
  });
});
