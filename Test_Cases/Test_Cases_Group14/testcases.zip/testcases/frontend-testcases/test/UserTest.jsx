import { render, screen, fireEvent, waitFor } from '@testing-library/react';
import Admin_Users from './User'; // path to your User.jsx
import axios from 'axios';
import Cookies from 'js-cookie';
import { toast } from 'react-toastify';
import { jwtDecode } from 'jwt-decode';

// Mocking Axios, Cookies, jwtDecode, and Toast notifications
jest.mock('axios');
jest.mock('js-cookie');
jest.mock('jwt-decode');
jest.mock('react-toastify');

describe('Admin_Users Component', () => {

  beforeEach(() => {
    // Clear all mocks before each test
    axios.mockClear();
    Cookies.get.mockClear();
    jwtDecode.mockClear();
    toast.info.mockClear();
  });

  it('should not fetch user data when no token is provided', async () => {
    Cookies.get.mockReturnValueOnce(undefined); // No token

    render(<Admin_Users />);
    
    await waitFor(() => {
      // Since there’s no token, no user data should be displayed
      expect(screen.queryByText(/User/)).toBeNull();
    });
  });

  it('should fetch user data when a valid token is provided', async () => {
    const mockUser = { user_id: '123' };
    const mockResponse = { data: { username: 'testUser', email: 'test@example.com' } };
    Cookies.get.mockReturnValueOnce('validToken');
    jwtDecode.mockReturnValueOnce(mockUser);
    axios.get.mockResolvedValueOnce(mockResponse);

    render(<Admin_Users />);

    await waitFor(() => {
      expect(axios.get).toHaveBeenCalledWith('http://localhost:3000/user/123', expect.any(Object));
      expect(screen.getByText('testUser')).toBeInTheDocument(); // Verifying user data is rendered
    });
  });

  it('should display a list of admin users', async () => {
    const mockAdminUsers = [
      { _id: '1', username: 'admin1', blocked: false, role: 'admin' },
      { _id: '2', username: 'admin2', blocked: false, role: 'user' }
    ];
    axios.get.mockResolvedValueOnce({ data: mockAdminUsers });

    render(<Admin_Users />);

    await waitFor(() => {
      mockAdminUsers.forEach(user => {
        expect(screen.getByText(user.username)).toBeInTheDocument(); // Check if users are listed
      });
    });
  });

  it('should disable a user and show a toast notification on success', async () => {
    const mockAdminUsers = [
      { _id: '1', username: 'admin1', blocked: false, role: 'admin' }
    ];
    axios.get.mockResolvedValueOnce({ data: mockAdminUsers });
    axios.patch.mockResolvedValueOnce({ data: { message: 'User disabled successfully' } });

    render(<Admin_Users />);

    const disableButton = screen.getByText('admin1'); // Find the button for the user
    fireEvent.click(disableButton);

    await waitFor(() => {
      expect(axios.patch).toHaveBeenCalledWith(
        'http://localhost:3000/admin/users/1/disable',
        expect.any(Object),
        expect.any(Object)
      );
      expect(toast.info).toHaveBeenCalledWith('User disabled successfully'); // Toast notification should appear
    });
  });

  it('should handle failure when disabling a user', async () => {
    const mockAdminUsers = [
      { _id: '1', username: 'admin1', blocked: false, role: 'admin' }
    ];
    axios.get.mockResolvedValueOnce({ data: mockAdminUsers });
    axios.patch.mockRejectedValueOnce(new Error('Failed to disable user'));

    render(<Admin_Users />);

    const disableButton = screen.getByText('admin1');
    fireEvent.click(disableButton);

    await waitFor(() => {
      expect(axios.patch).toHaveBeenCalledWith(
        'http://localhost:3000/admin/users/1/disable',
        expect.any(Object),
        expect.any(Object)
      );
      // Check if the error is logged in the console
      expect(console.error).toHaveBeenCalledWith(new Error('Failed to disable user'));
    });
  });

  it('should show a toast notification on failure to disable user', async () => {
    const mockAdminUsers = [
      { _id: '1', username: 'admin1', blocked: false, role: 'admin' }
    ];
    axios.get.mockResolvedValueOnce({ data: mockAdminUsers });
    axios.patch.mockRejectedValueOnce(new Error('Failed to disable user'));

    render(<Admin_Users />);

    const disableButton = screen.getByText('admin1');
    fireEvent.click(disableButton);

    await waitFor(() => {
      expect(toast.info).toHaveBeenCalledWith('Failed to disable user'); // Expected toast on failure
    });
  });
});
